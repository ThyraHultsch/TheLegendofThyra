
Für ein optimale Nutzererlebnis empfehle ich die Browseranwendung Google Chrome. 


Github Pages: https://thyrahultsch.github.io/TheLegendofThyra/Endabgabe/Startbildschirm.html