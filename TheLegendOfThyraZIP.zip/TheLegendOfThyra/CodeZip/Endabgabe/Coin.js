"use strict";
var TheLegendOfThyra;
(function (TheLegendOfThyra) {
    class Coin extends TheLegendOfThyra.GameObject {
        constructor(_name, _position, _size, _material) {
            super(_name, _position, _size, _material);
        }
    }
    TheLegendOfThyra.Coin = Coin;
})(TheLegendOfThyra || (TheLegendOfThyra = {}));
//# sourceMappingURL=Coin.js.map