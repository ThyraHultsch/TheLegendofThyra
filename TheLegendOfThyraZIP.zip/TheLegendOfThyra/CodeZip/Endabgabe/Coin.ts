namespace TheLegendOfThyra {

  export class Coin extends GameObject {


    public constructor(_name: string, _position: fc.Vector2, _size: fc.Vector2, _material: string) {

      super(_name, _position, _size, _material);

    
    }

  }

}